INSTRUCTIONS FOR INSTALLATION AND RUNNING (Platform independent as all commands will execute depending on the version/platform of nodejs installed):

1. Download and install nodejs from http://nodejs.org/download/
2. Open command prompt, navigate to the folder where you unpacked the application folder (root folder where this readme file resides)
3. type "npm install" for dependencies to install
4. type "node index.js" to run the nodejs+socketio server while in the same application root folder
5. Open chrome or firefox and go to http://localhost:3131. You may open other tabs or a new browser, and start typing chat messages to see them refreshed without the need for a page refresh!
6. Please ignore the lack of sanitation/security measures/efficiency/testing and bad taste in design, as if I had more time I would have done these